package com.example.producingwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducingWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
